#%%
import re
import pandas as pd
import os
from collections import Counter

folder_path = "SOU_SKRAPAREN\Output_copy"
file_paths = []
file_names = []

# Hämta alla .txt-filer och spara både sökvägar och filnamn
for root, dirs, files in os.walk(folder_path):
    for filename in files:
        if filename.endswith('.txt'):
            file_path = os.path.join(root, filename)
            file_paths.append(file_path)
            file_names.append(filename) 

output_input_pairs = []
for i, (path, filename) in enumerate(zip(file_paths, file_names)):  #Kopplar filnamn till rätt sökväg
    with open(path, 'r', encoding="utf-8") as f:
        text = f.read()
    output = filename.replace('kapitel_ärendet_och_dess_beredning_', '').replace('.txt', '', 1) 
    patterns = {
    "SOU": r'\bSOU\s\d{4}:\d+\b'            # Ex: SOU 2023:15
    }

# Extrahera matchningar för varje typ av referens
    extracted_inputs = []
    for key, pattern in patterns.items():
        matches = re.findall(pattern, text)
        extracted_inputs.extend(matches)
    

    inputs = [num for num in extracted_inputs if num != output] 
    inputs=list(set(inputs)) 
    output_input_pairs.append({
    "Output": output,
    "Inputs": "; ".join(inputs)  # Spara inputs som semikolon-separerad sträng
    })

df_links = pd.DataFrame(output_input_pairs)
df_links.to_csv('output_input_links_SOU.csv', index=False, encoding='utf-8')
print(" Länkad CSV sparad som 'output_input_links_SOU.csv'")
