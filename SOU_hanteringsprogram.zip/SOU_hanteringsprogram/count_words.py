#this module will take a set of txt files, read them, and count the words in each file, adding them to a total word count.
# it will then create a txt file with the 100 most common words in the files, and a csv file with the word counts for each file. 

import os

stop_words = []
#open the stop words file and read it into a list
with open("SOU_hanteringsprogram/stoppord.txt", "r", encoding="utf-8") as stop_words_file:
    stop_words = stop_words_file.read().splitlines()

def count_words_in_txt(file_name, word_count, stop_words, total_amount_of_words):

    with open(file_name, "r", encoding="utf-8") as f:
        string = f.read()

    string = string.replace("\n", " ").replace(".","").replace(",","").replace("(","").replace(")","").replace("!","").replace("?","").replace(":","").replace(";","").replace("-","").replace("_","").replace("  "," ").lower()
    word_list = string.split(" ")

    #count the occurance of each word in the word list
    if word_count == None:
        word_count = {}
    for word in word_list:
        if word in stop_words:
            #move on to the next iteration
            continue
        if word == "":
            #move on to the next iteration
            continue
        if word in word_count:
            word_count[word] += 1
        else:
            word_count[word] = 1

    total_amount_of_words += len(word_list)
    return word_count, total_amount_of_words


word_count = None
total_amount_of_words = 0
for file_name in os.listdir("SOU_hanteringsprogram/relevanta_propositioner"):
    if file_name.endswith(".txt"):
        file_name = "SOU_hanteringsprogram/relevanta_propositioner/"+file_name
        print("counting words in: ", file_name)
        word_count, total_amount_of_words = count_words_in_txt(file_name, word_count, stop_words, total_amount_of_words)

with open("SOU_hanteringsprogram/props_common_words.txt", "w", encoding="utf-8") as f:
    f.write("word: {count, count/amount_of_words}\n")

    for word, count in sorted(word_count.items(), key=lambda x: x[1], reverse=True):
        try:
            f.write(f"{word}: {count, count/total_amount_of_words}\n")
        except:
            print(f"Error writing {word} to file")
            continue