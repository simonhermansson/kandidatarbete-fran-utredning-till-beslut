# %% Sorterar dokumenten som mest liknar de nämnda SOUerna
import re
import pandas as pd
import os
from collections import Counter

folder_path = 'SOU_hanteringsprogram/alla_SOUer'  # Sökväg till mappen med .txt-filer
file_paths = []
file_names = []


# Hämta alla .txt-filer och spara både sökvägar och filnamn
for root, dirs, files in os.walk(folder_path):
    for filename in files:
        if filename.endswith('.txt'):
            file_path = os.path.join(root, filename)
            file_paths.append(file_path)
            file_names.append(filename)  # **Filnamnet sparas här**

# Läs in relevanta ord och gör dem små bokstäver
with open('SOU_hanteringsprogram/relevanta_ord_malin.txt', "r", encoding="utf-8") as relevanta_ord_path:
    text = relevanta_ord_path.read()

relevanta_ord = list(set(re.findall(r'\b\w+\b', text.lower())))  # Gör allt lowercase

# Dictionary för att lagra word count per dokument
output_word_counts = {}
word_regex = re.compile(r"\b\w+\b")

# Loop genom alla dokument
for i, (path, filename) in enumerate(zip(file_paths, file_names)):  # **Kopplar filnamn till rätt sökväg**
    with open(path, 'r', encoding="utf-8") as f:
        text = f.read().lower()  # Gör all text lowercase
        all_words = word_regex.findall(text)
        amount_of_words = len(all_words)  # Totalt antal ord i dokumentet

    # Räkna förekomster av relevanta ord (matcha oavsett stor/liten bokstav)
    relevanta_ord_set = set(relevanta_ord)
    word_counts = Counter(word for word in all_words if word in relevanta_ord_set)

    if not word_counts:
        continue

    total_matched_words = sum(word_counts.values())  # Totalt antal matchningar

    # Spara word counts för varje dokument
    output_word_counts[filename] = {
        "word_counts": word_counts,
        "total_matched_words": total_matched_words,
        "total_amount_of_words": amount_of_words
    }
    print(i)

# **Sortera efter antal matchade ord (högst först)**
sorted_outputs = sorted(output_word_counts.items(), key=lambda x: x[1]["total_matched_words"], reverse=True)


top_outputs = sorted_outputs

# **Skapa CSV-fil för ordmatris**
df_words = pd.DataFrame([
    {**{'Document Name': output, 'Total_Words': data["total_matched_words"], 'Total_Amount_of_Words': data["total_amount_of_words"]},}
    for output, data in top_outputs
])

# Fyll NaN med 0 och konvertera till heltal
df_words.fillna(0, inplace=True)
df_words = df_words.astype(int, errors='ignore')

# Spara ordmatrisen
df_words.to_csv('SOU_hanteringsprogram/differensskript/alla_souer_sorterade_efter_relevans_malin.csv', index=False, encoding="utf-8")

print(f"Antal rader i ordmatris CSV: {len(df_words)}")