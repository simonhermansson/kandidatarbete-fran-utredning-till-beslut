import pandas as pd
import os

#%% Rename files in a folder based on a csv file and move them to a new folder

def rename_files_in_folder(folder, csv_path, destination_folder):
    #check if the folder exists
    if not os.path.exists(folder):
        print(f"Folder {folder} does not exist.")
        return
    #check if the destination folder exists
    if not os.path.exists(destination_folder):
        #create the destination folder
        os.makedirs(destination_folder)

    #make a dataframe from the csv file
    df = pd.read_csv(csv_path)

    #loop through the rows of the dataframe and print the values of second column
    for index, row in df.iterrows():
        capitalized_filename = row[1]
        #make all letters in the filename small letters
        filename = capitalized_filename.lower()+".txt"
        
        path = folder + "/" + filename

        #for that file in folder, change the filename to the values of columns 5+3+4 of the dataframe
        #save the file in the destination folder
        if type(row[7])==float:
            new_filename = str(row[4]) +"_"+ str(row[2]) +"_"+ str(row[3]) +".txt"
        else:
            new_filename = str(row[4]).upper() +"_"+ str(row[2]) +"_"+ str(row[3]) +"-" + str(row[7]) + ".txt"
        new_path = folder + "/" + new_filename

        #move the file to the destination folder
        try:
            os.rename(path, destination_folder + "/" + new_filename)
        except:
            print(f"Failed to rename {path} to {new_filename}. it may already exist in the destination folder.")
            continue
csv_path = "csv_files\sou-2020-.csv"
folder = "text_files\sou-2020-.text"

destination_folder = "alla_SOUer"

#call the function to rename the files in the folder
# rename_files_in_folder(folder, csv_path, destination_folder)

#%% remove the inputs in the folder that are included in the cleaned csv file


cleaned_csv_path = "SOU_hanteringsprogram\SOU_SKRAPAREN\output_input_links_SOU_cleaned.csv"
#make a dataframe from the csv file
df = pd.read_csv(cleaned_csv_path)

#check the amount of strings in the Inputs column
i = 0
for _,row in df.iterrows():
        i += len(row["Inputs"].split(";"))
print("Inputs in csv:",i)

#loop through the folder of all sou files and move the files that are included in the cleaned csv file to the folder "SOU_hanteringsprogram\nämnda_SOUer"
import os
import shutil
def make_named_and_unnamed():
    folder_all_sou = "SOU_hanteringsprogram/alla_SOUer"
    folder_named_sous = "SOU_hanteringsprogram/nämnda_SOUer"
    folder_non_named_sous = "SOU_hanteringsprogram\ej_nämnda_SOUer"
    named = []
    unnamed = []
    for file in os.listdir(folder_all_sou):

        #check if the file string is included as a substring in the strings of the dataframe Inputs column

        file_without_extension = file.split(".")[0].split("-")[0]
        if df['Inputs'].str.contains(file_without_extension.upper()).any():
            #copy the file to SOU_hanteringsprogram\nämnda_SOUer
            # print(f"moving {file_without_extension}")
            shutil.copy2(folder_all_sou+"/"+file, folder_named_sous)
            
            named.append(file)

        else:
            shutil.copy2(folder_all_sou+"/"+file, folder_non_named_sous)
            unnamed.append(file)

    print("named:",len(named))
    print("non named:",len(unnamed))
    
#%%

