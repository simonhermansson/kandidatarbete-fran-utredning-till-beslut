

with open('SOU_hanteringsprogram/word_count_total.txt', "r", encoding="utf-8") as relevanta_ord_path:
    text = relevanta_ord_path.read()
#vi exkluderar den första raden i word_count_total.txt som är en rubrik
#dela upp texten i rader och loopa igenom dem
#lägg till varje ord i en lista
relevanta_ord = []
for line in text.splitlines()[1:10000]: # Exkludera första raden samt allt efter 10000
    #dela upp raden i ord och lägg till dem i listan
    word = line.split(":")[0]  # Ta bort allt efter ":"
    relevanta_ord.append(word.lower())  # Gör allt lowercase

print(relevanta_ord)

#write a new file called word_count_total_common.txt with the words in the list
with open('SOU_hanteringsprogram/word_count_total_common.txt', "w", encoding="utf-8") as f:
    for word in relevanta_ord:
        f.write(word + "\n")  # Skriv varje ord på en ny rad