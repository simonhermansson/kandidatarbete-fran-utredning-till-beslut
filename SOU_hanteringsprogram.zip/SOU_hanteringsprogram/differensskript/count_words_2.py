import os

def count_words_in_txt(file_name, word_count, stop_words, total_amount_of_words):

    with open(file_name, "r", encoding="utf-8") as f:
        string = f.read()

    string = string.replace("\n", " ").replace(".","").replace(",","").replace("(","").replace(")","").replace("!","").replace("?","").replace(":","").replace(";","").replace("-","").replace("_","").replace("  "," ").lower()
    word_list = string.split(" ")

    #count the occurance of each word in the word list
    if word_count == None:
        word_count = {}
    for word in word_list:
        if word in stop_words:
            #move on to the next iteration
            continue
        if word == "":
            #move on to the next iteration
            continue
        if word in word_count:
            word_count[word] += 1
        else:
            word_count[word] = 1

    total_amount_of_words += len(word_list)
    return word_count, total_amount_of_words

#make a list of the files to pass intp the function
with open("SOU_hanteringsprogram/differensskript/relevant_sous_joel.txt", "r", encoding="utf-8") as f: #this txt file includes row separated filenames of sous to be pu into the count_words_in_txt function
    file_list = f.read().splitlines()
    f.close()

stop_words = []
word_count = None
total_amount_of_words = 0
for file_name in file_list:
    if file_name.endswith(".txt"):
        file_name = "SOU_hanteringsprogram/alla_SOUer/"+file_name
        print("counting words in: ", file_name)
        word_count, total_amount_of_words = count_words_in_txt(file_name, word_count, stop_words, total_amount_of_words)

with open("SOU_hanteringsprogram/relevant_SOUs_common_words.txt", "w", encoding="utf-8") as f:
    f.write("word: {count, count/amount_of_words}\n")

    for word, count in sorted(word_count.items(), key=lambda x: x[1], reverse=True):
        try:
            f.write(f"{word}: {count, count/total_amount_of_words}\n")
        except:
            print(f"Error writing {word} to file")
            continue

