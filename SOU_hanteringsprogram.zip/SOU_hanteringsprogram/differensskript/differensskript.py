#detta skript ska ta två txt-filer med ord och deras frekvens och skapa en ny txt fil som innehåller differensen mellan de två filernas värden.

#here is an example of how the txt files should look like:
# word: {count, count/amount_of_words} #this first line is the header of the file and should be excluded from the comparison
# att: (84882, 0.027995197920858042) #we need to extract the second value from the tuple and compare it to the other file
# och: (83242, 0.027454304391131983)

def difference(txt_path1, txt_path2, stop_words): #returns the difference between file1 and file2 in a new file
    print("Calculating the difference between the two files...")
    with open(txt_path1, "r", encoding="utf-8") as f:
        file1 = f.readlines()
        f.close()

    with open(txt_path2, "r", encoding="utf-8") as f:
        file2 = f.readlines()
        f.close()

    #remove the first line from both files
    file1 = file1[1:]
    file2 = file2[1:]

    #create a dictionary for each file with the word as key and the count as value
    file1_dict = {}
    file2_dict = {}
    for line in file1:
        line = line.split(": ")
        word = line[0]
        frequency = line[1].split(",")[1].replace(")","").replace(" ","").replace("\n","")
        file1_dict[word] = float(frequency)

    for line in file2:
        line = line.split(": ")
        word = line[0]
        frequency = line[1].split(",")[1].replace(")","").replace(" ","").replace("\n","")
        file2_dict[word] = float(frequency)

    #create a new dictionary with the difference between the two files
    diff_dict = {}
    for word in file1_dict:
        if word in stop_words:
            #move on to the next iteration
            continue
        if word in file2_dict:
            diff = file1_dict[word] - file2_dict[word]
            if diff < 0:#if the result is negative, we can skip it
                continue
            else: #if the result is positive, we add it to the dictionary
                diff_dict[word] = diff
        else:
            diff_dict[word] = file1_dict[word]



    #before writing, we sort the diff_dict by the values in descending order
    diff_dict = dict(sorted(diff_dict.items(), key=lambda x: x[1], reverse=True))

    #write the results to a new file with a similar format as the input files but without the first value of the tuple
    with open("SOU_hanteringsprogram/differensskript/relevanta_ord_differens.txt", "w", encoding="utf-8") as f:
        f.write("word: {count/amount_of_words}\n")
        for word in diff_dict:
            f.write(f"{word}: {diff_dict[word]}\n")
        f.close()

stop_words = []
#open the stop words file and read it into a list
with open("SOU_hanteringsprogram/stoppord.txt", "r", encoding="utf-8") as stop_words_file:
    stop_words = stop_words_file.read().splitlines()
    stop_words_file.close()
difference("SOU_hanteringsprogram/differensskript/relevant_SOUs_common_words.txt","SOU_hanteringsprogram/differensskript/all_SOUs_common_words.txt", stop_words)